"use client";

import { useState, useEffect, useCallback } from 'react';
import { 
  getAllFromStore, 
  addToStore, 
  deleteFromStore, 
  Product, 
  Category, 
  Transaction, 
  TransactionItem 
} from '@/lib/db';

export function usePOS() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [cart, setCart] = useState<TransactionItem[]>([]);
  const [loading, setLoading] = useState(true);

  const refreshData = useCallback(async () => {
    try {
      const [p, c, t] = await Promise.all([
        getAllFromStore<Product>('products'),
        getAllFromStore<Category>('categories'),
        getAllFromStore<Transaction>('transactions'),
      ]);
      setProducts(p);
      setCategories(c);
      setTransactions(t.sort((a, b) => b.timestamp - a.timestamp));
    } catch (err) {
      console.error('Failed to load data from IndexedDB', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.productId === product.id);
      if (existing) {
        return prev.map(item => 
          item.productId === product.id 
            ? { ...item, quantity: item.quantity + 1 } 
            : item
        );
      }
      return [...prev, { 
        productId: product.id, 
        name: product.name, 
        price: product.price, 
        quantity: 1 
      }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.productId !== productId));
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.productId === productId) {
        const newQty = Math.max(0, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }).filter(item => item.quantity > 0));
  };

  const checkout = async (paymentMethod: 'cash' | 'card') => {
    if (cart.length === 0) return;

    const total = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
    const newTransaction: Transaction = {
      id: crypto.randomUUID(),
      timestamp: Date.now(),
      items: [...cart],
      total,
      paymentMethod,
    };

    await addToStore('transactions', newTransaction);
    setCart([]);
    refreshData();
  };

  const addProduct = async (product: Omit<Product, 'id'>) => {
    const newProduct = { ...product, id: crypto.randomUUID() };
    await addToStore('products', newProduct);
    refreshData();
  };

  const deleteProduct = async (id: string) => {
    await deleteFromStore('products', id);
    refreshData();
  };

  const addCategory = async (category: Omit<Category, 'id'>) => {
    const newCategory = { ...category, id: crypto.randomUUID() };
    await addToStore('categories', newCategory);
    refreshData();
  };

  const deleteCategory = async (id: string) => {
    await deleteFromStore('categories', id);
    refreshData();
  };

  const clearCart = () => setCart([]);

  return {
    products,
    categories,
    transactions,
    cart,
    loading,
    addToCart,
    removeFromCart,
    updateQuantity,
    checkout,
    clearCart,
    addProduct,
    deleteProduct,
    addCategory,
    deleteCategory,
    refreshData,
  };
}
