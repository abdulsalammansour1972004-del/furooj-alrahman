"use client";

import { useState } from 'react';
import { Transaction } from '@/lib/db';
import { ScrollArea } from '@/components/ui/scroll-area';
import { format } from 'date-fns';
import { Search, Receipt, ChevronRight, Calendar, Banknote, CreditCard } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';

interface HistoryPanelProps {
  transactions: Transaction[];
}

export function HistoryPanel({ transactions }: HistoryPanelProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const filtered = transactions.filter(t => 
    t.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.items.some(i => i.name.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const selectedTransaction = transactions.find(t => t.id === selectedId);

  const todaySales = transactions
    .filter(t => new Date(t.timestamp).toDateString() === new Date().toDateString())
    .reduce((acc, t) => acc + t.total, 0);

  return (
    <div className="flex h-full flex-1 overflow-hidden">
      <div className="w-full max-w-md border-r bg-white flex flex-col h-full">
        <div className="p-6 border-b space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold">Transaction History</h2>
            <div className="bg-primary/10 text-primary px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
              {transactions.length} total
            </div>
          </div>
          
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search by ID or Item..." 
              className="pl-10 bg-muted/30 border-none rounded-xl"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div className="p-4 bg-primary text-white rounded-xl shadow-inner shadow-black/5">
            <div className="text-xs uppercase font-bold opacity-80">Today's Sales Total</div>
            <div className="text-3xl font-black font-mono mt-1">${todaySales.toFixed(2)}</div>
          </div>
        </div>

        <ScrollArea className="flex-1">
          <div className="divide-y">
            {filtered.length === 0 ? (
              <div className="p-12 text-center text-muted-foreground opacity-50">
                <Search className="w-12 h-12 mx-auto mb-4" />
                <p>No transactions found</p>
              </div>
            ) : (
              filtered.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setSelectedId(t.id)}
                  className={cn(
                    "w-full text-left p-4 hover:bg-muted/50 transition-colors flex items-center justify-between group",
                    selectedId === t.id && "bg-primary/5"
                  )}
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <div className={cn(
                        "p-1.5 rounded-md",
                        t.paymentMethod === 'card' ? "bg-blue-100 text-blue-600" : "bg-green-100 text-green-600"
                      )}>
                        {t.paymentMethod === 'card' ? <CreditCard size={14} /> : <Banknote size={14} />}
                      </div>
                      <span className="font-mono text-xs text-muted-foreground">#{t.id.slice(0, 8)}</span>
                    </div>
                    <div className="font-bold">${t.total.toFixed(2)}</div>
                    <div className="text-xs text-muted-foreground flex items-center gap-1">
                      <Calendar size={12} />
                      {format(t.timestamp, 'MMM dd, HH:mm')}
                    </div>
                  </div>
                  <ChevronRight className={cn(
                    "w-5 h-5 text-muted-foreground transition-transform",
                    selectedId === t.id && "translate-x-1 text-primary"
                  )} />
                </button>
              ))
            )}
          </div>
        </ScrollArea>
      </div>

      <div className="flex-1 bg-muted/20 p-8">
        {selectedTransaction ? (
          <Card className="max-w-md mx-auto bg-white shadow-xl p-8 space-y-6">
            <div className="text-center space-y-2 pb-6 border-b border-dashed">
               <h1 className="text-2xl font-black uppercase tracking-widest text-primary">CluckCounter</h1>
               <p className="text-xs text-muted-foreground italic">Thank you for your business!</p>
               <div className="text-xs font-mono text-muted-foreground mt-4">
                  ID: {selectedTransaction.id}<br/>
                  DATE: {format(selectedTransaction.timestamp, 'yyyy-MM-dd HH:mm:ss')}<br/>
                  METHOD: {selectedTransaction.paymentMethod.toUpperCase()}
               </div>
            </div>

            <div className="space-y-4 py-4">
              {selectedTransaction.items.map((item, idx) => (
                <div key={idx} className="flex justify-between text-sm">
                  <div className="flex gap-4">
                    <span className="font-bold text-primary">{item.quantity}x</span>
                    <span>{item.name}</span>
                  </div>
                  <span className="font-mono">${(item.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
            </div>

            <div className="pt-6 border-t border-dashed space-y-2">
               <div className="flex justify-between text-xl font-black">
                 <span>TOTAL</span>
                 <span className="text-primary">${selectedTransaction.total.toFixed(2)}</span>
               </div>
               <div className="text-[10px] text-muted-foreground text-center pt-8">
                 ALL SALES FINAL • OFFLINE RECORD GENERATED
               </div>
            </div>
          </Card>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-muted-foreground gap-4">
            <Receipt className="w-16 h-16 opacity-20" />
            <p>Select a transaction to view receipt details</p>
          </div>
        )}
      </div>
    </div>
  );
}
