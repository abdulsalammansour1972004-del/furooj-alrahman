"use client";

import { LayoutDashboard, History, Settings, Store } from 'lucide-react';
import { cn } from '@/lib/utils';

type View = 'sales' | 'history' | 'manage';

interface SidebarNavProps {
  currentView: View;
  onViewChange: (view: View) => void;
}

export function SidebarNav({ currentView, onViewChange }: SidebarNavProps) {
  const navItems = [
    { id: 'sales', label: 'Point of Sale', icon: Store },
    { id: 'history', label: 'Transactions', icon: History },
    { id: 'manage', label: 'Management', icon: Settings },
  ] as const;

  return (
    <div className="w-20 bg-white border-r flex flex-col items-center py-6 gap-6 shadow-sm">
      <div className="p-3 bg-primary rounded-xl mb-4">
        <Store className="w-6 h-6 text-white" />
      </div>
      
      <div className="flex flex-col gap-2 w-full px-2">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onViewChange(item.id)}
            className={cn(
              "p-4 rounded-xl transition-all duration-200 flex flex-col items-center gap-1 group",
              currentView === item.id 
                ? "bg-primary/10 text-primary" 
                : "text-muted-foreground hover:bg-muted hover:text-foreground"
            )}
            title={item.label}
          >
            <item.icon className="w-6 h-6" />
            <span className="text-[10px] font-medium uppercase tracking-tighter opacity-0 group-hover:opacity-100 transition-opacity">
              {item.id}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}
