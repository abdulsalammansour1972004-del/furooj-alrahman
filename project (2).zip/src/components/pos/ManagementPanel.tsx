"use client";

import { useState } from 'react';
import { Product, Category } from '@/lib/db';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Trash2, Plus, Drumstick, Utensils, CupSoda, Droplets } from 'lucide-react';

interface ManagementPanelProps {
  products: Product[];
  categories: Category[];
  onAddProduct: (p: Omit<Product, 'id'>) => void;
  onDeleteProduct: (id: string) => void;
  onAddCategory: (c: Omit<Category, 'id'>) => void;
  onDeleteCategory: (id: string) => void;
}

export function ManagementPanel({ 
  products, 
  categories, 
  onAddProduct, 
  onDeleteProduct, 
  onAddCategory, 
  onDeleteCategory 
}: ManagementPanelProps) {
  const [newProduct, setNewProduct] = useState({ name: '', price: '', categoryId: '' });
  const [newCategory, setNewCategory] = useState({ name: '', icon: 'Drumstick' });

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newProduct.name || !newProduct.price || !newProduct.categoryId) return;
    onAddProduct({
      name: newProduct.name,
      price: parseFloat(newProduct.price),
      categoryId: newProduct.categoryId,
    });
    setNewProduct({ name: '', price: '', categoryId: '' });
  };

  const handleAddCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategory.name) return;
    onAddCategory(newCategory);
    setNewCategory({ name: '', icon: 'Drumstick' });
  };

  return (
    <div className="flex-1 p-8 bg-muted/20 overflow-auto">
      <div className="max-w-4xl mx-auto space-y-8">
        <header>
          <h1 className="text-3xl font-black tracking-tight">Shop Management</h1>
          <p className="text-muted-foreground">Configure your menu and categories. Everything is stored locally on this device.</p>
        </header>

        <Tabs defaultValue="products">
          <TabsList className="grid w-full grid-cols-2 max-w-md mb-8">
            <TabsTrigger value="products">Menu Items</TabsTrigger>
            <TabsTrigger value="categories">Categories</TabsTrigger>
          </TabsList>

          <TabsContent value="products" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Add New Item</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleAddProduct} className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                  <div className="space-y-2">
                    <Label>Product Name</Label>
                    <Input 
                      placeholder="e.g. Buffalo Wings" 
                      value={newProduct.name}
                      onChange={e => setNewProduct({...newProduct, name: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Price ($)</Label>
                    <Input 
                      type="number" 
                      step="0.01" 
                      placeholder="9.99"
                      value={newProduct.price}
                      onChange={e => setNewProduct({...newProduct, price: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Category</Label>
                    <Select onValueChange={v => setNewProduct({...newProduct, categoryId: v})} value={newProduct.categoryId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select Category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map(c => (
                          <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <Button type="submit" className="bg-primary hover:bg-primary/90">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Product
                  </Button>
                </form>
              </CardContent>
            </Card>

            <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
               <table className="w-full text-left">
                  <thead className="bg-muted/50 border-b">
                     <tr>
                        <th className="px-6 py-4 font-bold text-xs uppercase tracking-wider">Name</th>
                        <th className="px-6 py-4 font-bold text-xs uppercase tracking-wider">Category</th>
                        <th className="px-6 py-4 font-bold text-xs uppercase tracking-wider">Price</th>
                        <th className="px-6 py-4 font-bold text-xs uppercase tracking-wider text-right">Actions</th>
                     </tr>
                  </thead>
                  <tbody className="divide-y">
                     {products.map(p => (
                        <tr key={p.id} className="hover:bg-muted/30">
                           <td className="px-6 py-4 text-sm font-medium">{p.name}</td>
                           <td className="px-6 py-4 text-sm text-muted-foreground">
                              {categories.find(c => c.id === p.categoryId)?.name || 'Unknown'}
                           </td>
                           <td className="px-6 py-4 text-sm font-mono">${p.price.toFixed(2)}</td>
                           <td className="px-6 py-4 text-right">
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => onDeleteProduct(p.id)}
                                className="text-muted-foreground hover:text-destructive"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                           </td>
                        </tr>
                     ))}
                  </tbody>
               </table>
            </div>
          </TabsContent>

          <TabsContent value="categories" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Add New Category</CardTitle>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleAddCategory} className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
                  <div className="space-y-2">
                    <Label>Category Name</Label>
                    <Input 
                      placeholder="e.g. Dipping Sauces" 
                      value={newCategory.name}
                      onChange={e => setNewCategory({...newCategory, name: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Icon</Label>
                    <Select onValueChange={v => setNewCategory({...newCategory, icon: v})} value={newCategory.icon}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Drumstick">Chicken Leg</SelectItem>
                        <SelectItem value="Utensils">Utensils</SelectItem>
                        <SelectItem value="CupSoda">Drink</SelectItem>
                        <SelectItem value="Droplets">Dip</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button type="submit" className="bg-primary hover:bg-primary/90">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Category
                  </Button>
                </form>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {categories.map(c => (
                <div key={c.id} className="flex items-center justify-between p-4 bg-white rounded-xl shadow-sm border group">
                  <div className="flex items-center gap-3">
                    <div className="bg-primary/10 p-2 rounded-lg text-primary">
                      {c.icon === 'Drumstick' && <Drumstick size={20} />}
                      {c.icon === 'Utensils' && <Utensils size={20} />}
                      {c.icon === 'CupSoda' && <CupSoda size={20} />}
                      {c.icon === 'Droplets' && <Droplets size={20} />}
                    </div>
                    <span className="font-bold">{c.name}</span>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => onDeleteCategory(c.id)}
                    className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
