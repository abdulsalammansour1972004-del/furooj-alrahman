"use client";

import { Trash2, Minus, Plus, CreditCard, Banknote, ReceiptText } from 'lucide-react';
import { TransactionItem } from '@/lib/db';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

interface CartPanelProps {
  items: TransactionItem[];
  onUpdateQty: (id: string, delta: number) => void;
  onRemove: (id: string) => void;
  onCheckout: (method: 'cash' | 'card') => void;
  onClear: () => void;
}

export function CartPanel({ items, onUpdateQty, onRemove, onCheckout, onClear }: CartPanelProps) {
  const subtotal = items.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const tax = subtotal * 0.08;
  const total = subtotal + tax;

  return (
    <div className="flex flex-col h-full bg-white border-l w-96 shadow-lg">
      <div className="p-6 border-b flex items-center justify-between bg-white sticky top-0 z-10">
        <div className="flex items-center gap-2">
          <ReceiptText className="w-5 h-5 text-primary" />
          <h2 className="text-xl font-bold tracking-tight">Active Order</h2>
        </div>
        {items.length > 0 && (
          <Button variant="ghost" size="sm" onClick={onClear} className="text-muted-foreground hover:text-accent">
            <Trash2 className="w-4 h-4 mr-2" />
            Clear
          </Button>
        )}
      </div>

      <ScrollArea className="flex-1 px-6">
        {items.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-muted-foreground opacity-50 text-center gap-4">
            <ReceiptText className="w-12 h-12" />
            <p>Your cart is empty.<br/>Add some chicken!</p>
          </div>
        ) : (
          <div className="py-4 space-y-4">
            {items.map((item) => (
              <div key={item.productId} className="flex flex-col gap-2 p-3 bg-muted/30 rounded-lg animate-slide-in">
                <div className="flex justify-between items-start">
                  <span className="font-semibold text-sm">{item.name}</span>
                  <span className="font-mono text-sm">${(item.price * item.quantity).toFixed(2)}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <button 
                      onClick={() => onUpdateQty(item.productId, -1)}
                      className="p-1 hover:bg-white rounded border"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-8 text-center text-sm font-bold">{item.quantity}</span>
                    <button 
                      onClick={() => onUpdateQty(item.productId, 1)}
                      className="p-1 hover:bg-white rounded border"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                  <button 
                    onClick={() => onRemove(item.productId)}
                    className="text-muted-foreground hover:text-destructive p-1"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </ScrollArea>

      <div className="p-6 bg-muted/10 border-t space-y-4">
        <div className="space-y-1.5 text-sm">
          <div className="flex justify-between text-muted-foreground">
            <span>Subtotal</span>
            <span>${subtotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-muted-foreground">
            <span>Tax (8%)</span>
            <span>${tax.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-lg font-bold border-t pt-2 mt-2">
            <span>Total</span>
            <span className="text-primary">${total.toFixed(2)}</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Button 
            disabled={items.length === 0}
            onClick={() => onCheckout('cash')}
            variant="outline" 
            className="h-14 flex flex-col gap-1 border-primary/20 hover:bg-primary/5 hover:border-primary"
          >
            <Banknote className="w-5 h-5 text-primary" />
            <span className="text-xs uppercase font-bold">Cash</span>
          </Button>
          <Button 
            disabled={items.length === 0}
            onClick={() => onCheckout('card')}
            variant="default" 
            className="h-14 flex flex-col gap-1 bg-accent hover:bg-accent/90"
          >
            <CreditCard className="w-5 h-5" />
            <span className="text-xs uppercase font-bold">Card</span>
          </Button>
        </div>
      </div>
    </div>
  );
}
