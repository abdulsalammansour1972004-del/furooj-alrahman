"use client";

import { useState } from 'react';
import { Product, Category } from '@/lib/db';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Plus, Drumstick, Utensils, CupSoda, Droplets, Info } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ProductGridProps {
  products: Product[];
  categories: Category[];
  onAddToCart: (p: Product) => void;
}

const ICON_MAP: Record<string, any> = {
  Drumstick,
  Utensils,
  CupSoda,
  Droplets,
};

export function ProductGrid({ products, categories, onAddToCart }: ProductGridProps) {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const filteredProducts = selectedCategory 
    ? products.filter(p => p.categoryId === selectedCategory)
    : products;

  return (
    <div className="flex flex-col flex-1 h-full overflow-hidden">
      {/* Category Nav */}
      <div className="flex gap-3 p-6 overflow-x-auto no-scrollbar">
        <Button
          variant={selectedCategory === null ? 'default' : 'outline'}
          onClick={() => setSelectedCategory(null)}
          className="rounded-full px-6 whitespace-nowrap"
        >
          All Items
        </Button>
        {categories.map((cat) => {
          const IconComp = ICON_MAP[cat.icon] || Info;
          return (
            <Button
              key={cat.id}
              variant={selectedCategory === cat.id ? 'default' : 'outline'}
              onClick={() => setSelectedCategory(cat.id)}
              className="rounded-full px-6 flex gap-2 whitespace-nowrap"
            >
              <IconComp className="w-4 h-4" />
              {cat.name}
            </Button>
          );
        })}
      </div>

      {/* Grid */}
      <ScrollArea className="flex-1 px-6 pb-6">
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-4">
          {filteredProducts.map((product) => (
            <Card 
              key={product.id}
              className="group overflow-hidden border-none shadow-md hover:shadow-xl transition-all cursor-pointer bg-white"
              onClick={() => onAddToCart(product)}
            >
              <div className="aspect-square bg-muted relative flex items-center justify-center p-8 group-hover:bg-primary/5 transition-colors">
                 <Drumstick className="w-16 h-16 text-muted-foreground/20 group-hover:text-primary/20 transition-colors" />
                 <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="bg-primary text-white p-2 rounded-full shadow-lg">
                       <Plus className="w-5 h-5" />
                    </div>
                 </div>
              </div>
              <div className="p-4 space-y-1">
                <h3 className="font-bold text-sm leading-tight line-clamp-2 min-h-[2.5rem]">{product.name}</h3>
                <p className="text-primary font-bold font-mono">${product.price.toFixed(2)}</p>
              </div>
            </Card>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}
