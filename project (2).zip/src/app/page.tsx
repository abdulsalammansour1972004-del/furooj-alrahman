"use client";

import { useState, useEffect, useCallback, useMemo } from 'react';
import { 
  getAllFromStore, 
  addToStore, 
  deleteFromStore, 
  Product, 
  Sale, 
  Purchase 
} from '@/lib/db';
import { 
  Package, 
  ShoppingCart, 
  Truck, 
  BarChart3, 
  History, 
  Plus, 
  Trash2, 
  Search,
  Calendar as CalendarIcon,
  ChevronRight,
  ChevronLeft
} from 'lucide-react';
import { format, isSameDay } from 'date-fns';
import { ar } from 'date-fns/locale';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';

type View = 'sales' | 'purchases' | 'inventory' | 'reports' | 'log';

export default function ChickenPOS() {
  const [currentView, setCurrentView] = useState<View>('sales');
  const [products, setProducts] = useState<Product[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [loading, setLoading] = useState(true);
  const [reportDate, setReportDate] = useState<Date>(new Date());
  const { toast } = useToast();

  const refreshData = useCallback(async () => {
    try {
      const [p, s, pur] = await Promise.all([
        getAllFromStore<Product>('products'),
        getAllFromStore<Sale>('sales'),
        getAllFromStore<Purchase>('purchases'),
      ]);
      setProducts(p);
      setSales(s.sort((a, b) => b.timestamp - a.timestamp));
      setPurchases(pur.sort((a, b) => b.timestamp - a.timestamp));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  const handleAddProduct = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const name = formData.get('name') as string;
    const purchasePrice = parseFloat(formData.get('purchasePrice') as string);
    const sellingPrice = parseFloat(formData.get('sellingPrice') as string);
    const initialQty = parseFloat(formData.get('initialQty') as string) || 0;

    if (!name || isNaN(purchasePrice) || isNaN(sellingPrice)) return;

    const newProduct: Product = {
      id: crypto.randomUUID(),
      name,
      purchasePrice,
      sellingPrice,
      currentQty: initialQty
    };

    await addToStore('products', newProduct);
    toast({ title: "تمت الإضافة", description: "تم إضافة المنتج بنجاح" });
    refreshData();
    e.currentTarget.reset();
  };

  const handleDeleteProduct = async (id: string) => {
    if(confirm("هل أنت متأكد من حذف هذا المنتج؟")) {
      await deleteFromStore('products', id);
      refreshData();
    }
  };

  const handleSale = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const productId = formData.get('productId') as string;
    const weight = parseFloat(formData.get('weight') as string);

    const product = products.find(p => p.id === productId);
    if (!product || isNaN(weight) || weight <= 0) return;

    if (product.currentQty < weight) {
      toast({ title: "خطأ", description: "المخزون غير كافٍ", variant: "destructive" });
      return;
    }

    const totalPrice = Math.round(weight * product.sellingPrice);
    const totalCost = Math.round(weight * product.purchasePrice);
    const profit = totalPrice - totalCost;

    const newSale: Sale = {
      id: crypto.randomUUID(),
      productId: product.id,
      productName: product.name,
      weight,
      pricePerKg: product.sellingPrice,
      totalPrice,
      costPerKg: product.purchasePrice,
      profit,
      timestamp: Date.now()
    };

    const updatedProduct = { ...product, currentQty: product.currentQty - weight };
    await addToStore('products', updatedProduct);
    await addToStore('sales', newSale);

    toast({ title: "تم البيع", description: `المبلغ: ${totalPrice.toLocaleString()} ل.س` });
    refreshData();
    e.currentTarget.reset();
  };

  const handlePurchase = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const productId = formData.get('productId') as string;
    const weight = parseFloat(formData.get('weight') as string);
    const pricePerKg = parseFloat(formData.get('pricePerKg') as string);

    const product = products.find(p => p.id === productId);
    if (!product || isNaN(weight) || isNaN(pricePerKg)) return;

    const newPurchase: Purchase = {
      id: crypto.randomUUID(),
      productId: product.id,
      productName: product.name,
      weight,
      pricePerKg,
      totalPrice: Math.round(weight * pricePerKg),
      timestamp: Date.now()
    };

    const updatedProduct = { 
      ...product, 
      currentQty: product.currentQty + weight,
      purchasePrice: pricePerKg 
    };
    
    await addToStore('products', updatedProduct);
    await addToStore('purchases', newPurchase);

    toast({ title: "تم التوريد", description: "تم تحديث المخزون" });
    refreshData();
    e.currentTarget.reset();
  };

  const getStatsByDate = (date: Date) => {
    const daySales = sales.filter(s => isSameDay(new Date(s.timestamp), date));
    const dayPurchases = purchases.filter(p => isSameDay(new Date(p.timestamp), date));

    return {
      salesTotal: daySales.reduce((acc, s) => acc + s.totalPrice, 0),
      purchasesTotal: dayPurchases.reduce((acc, p) => acc + p.totalPrice, 0),
      profitTotal: daySales.reduce((acc, s) => acc + s.profit, 0),
      salesCount: daySales.length,
      weightSold: daySales.reduce((acc, s) => acc + s.weight, 0),
      weightPurchased: dayPurchases.reduce((acc, p) => acc + p.weight, 0),
    };
  };

  const stats = useMemo(() => getStatsByDate(reportDate), [sales, purchases, reportDate]);
  const todayStats = useMemo(() => getStatsByDate(new Date()), [sales, purchases]);

  if (loading) return <div className="flex h-screen items-center justify-center text-xl font-bold">جاري التحميل...</div>;

  return (
    <div className="flex flex-col h-screen bg-gray-50 max-w-md mx-auto relative overflow-hidden">
      
      {/* Header */}
      <header className="bg-white border-b px-4 py-3 sticky top-0 z-20 shadow-sm flex items-center justify-between">
        <div>
          <h1 className="text-xl font-black text-primary">فروج الرحمن</h1>
          <p className="text-[10px] text-muted-foreground font-bold">لإدارة الدواجن - ليرة سورية</p>
        </div>
        <div className="bg-primary/10 px-2 py-1 rounded text-[10px] font-bold text-primary">أرشيف دائم</div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto pb-24">
        
        {/* Sales View */}
        {currentView === 'sales' && (
          <div className="p-4 space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
            <h2 className="text-xl font-bold">بيع جديد</h2>
            <Card className="border-none shadow-sm">
              <CardContent className="p-4">
                <form onSubmit={handleSale} className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-muted-foreground uppercase">المنتج</label>
                    <select 
                      name="productId" 
                      required 
                      className="w-full h-12 px-3 border rounded-xl bg-background focus:ring-2 focus:ring-primary outline-none transition-all text-sm font-bold appearance-none"
                    >
                      <option value="">اختر منتجاً</option>
                      {products.map(p => (
                        <option key={p.id} value={p.id}>{p.name} ({p.currentQty.toFixed(2)} كجم)</option>
                      ))}
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-muted-foreground uppercase">الوزن (كيلو)</label>
                    <Input name="weight" type="number" step="0.001" placeholder="0.000" required className="h-12 text-lg font-bold rounded-xl" />
                  </div>
                  <Button type="submit" className="w-full h-14 text-lg font-bold bg-green-600 hover:bg-green-700 shadow-lg active:scale-95 transition-transform">
                    <Plus className="ml-2 h-5 w-5" /> إتمام البيع
                  </Button>
                </form>
              </CardContent>
            </Card>

            <div className="grid grid-cols-2 gap-3">
              <div className="bg-green-600 text-white p-4 rounded-2xl shadow-sm">
                <p className="text-[10px] font-bold opacity-80 mb-1">مبيعات اليوم</p>
                <p className="text-lg font-black">{todayStats.salesTotal.toLocaleString()} <span className="text-[10px]">ل.س</span></p>
              </div>
              <div className="bg-blue-600 text-white p-4 rounded-2xl shadow-sm">
                <p className="text-[10px] font-bold opacity-80 mb-1">أرباح اليوم</p>
                <p className="text-lg font-black">{todayStats.profitTotal.toLocaleString()} <span className="text-[10px]">ل.س</span></p>
              </div>
            </div>
          </div>
        )}

        {/* Purchases View */}
        {currentView === 'purchases' && (
          <div className="p-4 space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
            <h2 className="text-xl font-bold">إضافة مشتريات (توريد)</h2>
            <Card className="border-none shadow-sm">
              <CardContent className="p-4">
                <form onSubmit={handlePurchase} className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-muted-foreground">المنتج</label>
                    <select name="productId" required className="w-full h-12 px-3 border rounded-xl bg-background text-sm font-bold">
                      <option value="">اختر منتجاً</option>
                      {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-muted-foreground">الكمية (كيلو)</label>
                      <Input name="weight" type="number" step="0.001" required className="h-12 font-bold" />
                    </div>
                    <div className="space-y-1">
                      <label className="text-xs font-bold text-muted-foreground">سعر الشراء / كغ</label>
                      <Input name="pricePerKg" type="number" step="1" required className="h-12 font-bold" />
                    </div>
                  </div>
                  <Button type="submit" className="w-full h-14 text-lg font-bold bg-blue-600 hover:bg-blue-700 shadow-lg">
                    تأكيد التوريد
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Inventory View */}
        {currentView === 'inventory' && (
          <div className="p-4 space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
            <h2 className="text-xl font-bold">إدارة المخزون</h2>
            
            <Card className="border-none shadow-sm">
              <CardHeader className="p-4 pb-2">
                <CardTitle className="text-sm">إضافة منتج جديد</CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0">
                <form onSubmit={handleAddProduct} className="space-y-3">
                  <Input name="name" required placeholder="اسم المنتج (مثلاً: دجاج كامل)" className="h-11" />
                  <div className="grid grid-cols-2 gap-3">
                    <Input name="purchasePrice" type="number" step="1" placeholder="سعر الشراء" required className="h-11" />
                    <Input name="sellingPrice" type="number" step="1" placeholder="سعر البيع" required className="h-11" />
                  </div>
                  <Input name="initialQty" type="number" step="0.001" placeholder="الكمية الحالية بالكيلو" className="h-11" />
                  <Button type="submit" className="w-full font-bold">حفظ المنتج</Button>
                </form>
              </CardContent>
            </Card>

            <div className="space-y-2">
              <h3 className="text-xs font-bold text-muted-foreground px-1">قائمة المنتجات والمخزون</h3>
              {products.map(p => (
                <div key={p.id} className="bg-white p-4 rounded-xl shadow-sm flex items-center justify-between border">
                  <div className="space-y-1">
                    <p className="font-bold text-sm">{p.name}</p>
                    <div className="flex gap-2 text-[10px] text-muted-foreground">
                      <span>شراء: {p.purchasePrice.toLocaleString()}</span>
                      <span>بيع: {p.sellingPrice.toLocaleString()}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-left">
                      <p className={cn("text-sm font-black", p.currentQty < 5 ? "text-red-600" : "text-primary")}>
                        {p.currentQty.toFixed(2)} كغ
                      </p>
                      <p className="text-[10px] text-muted-foreground">متاح</p>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => handleDeleteProduct(p.id)} className="text-red-500 h-8 w-8 p-0">
                      <Trash2 size={16} />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Reports & Archive View */}
        {currentView === 'reports' && (
          <div className="p-4 space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
            <div className="flex flex-col gap-2 mb-2">
              <h2 className="text-xl font-bold">تقرير الأيام (الأرشيف)</h2>
              <div className="flex items-center gap-2">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full h-12 justify-start text-right font-bold gap-3 rounded-xl">
                      <CalendarIcon className="h-4 w-4" />
                      {format(reportDate, 'dd MMMM yyyy', { locale: ar })}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={reportDate}
                      onSelect={(date) => date && setReportDate(date)}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                <Button variant="ghost" onClick={() => setReportDate(new Date())} className="h-12 px-4 rounded-xl border">اليوم</Button>
              </div>
            </div>

            <div className="space-y-3">
              <ReportMobileCard title="إجمالي المبيعات" value={stats.salesTotal} color="bg-green-50 text-green-700" />
              <ReportMobileCard title="إجمالي المشتريات" value={stats.purchasesTotal} color="bg-red-50 text-red-700" />
              <ReportMobileCard title="صافي الأرباح" value={stats.profitTotal} color="bg-blue-50 text-blue-700" />
              
              <div className="grid grid-cols-2 gap-3 mt-4">
                <div className="bg-gray-100 p-3 rounded-xl border text-center">
                  <p className="text-[10px] text-muted-foreground font-bold">عدد الفواتير</p>
                  <p className="text-lg font-black">{stats.salesCount}</p>
                </div>
                <div className="bg-gray-100 p-3 rounded-xl border text-center">
                  <p className="text-[10px] text-muted-foreground font-bold">وزن مباع</p>
                  <p className="text-lg font-black">{stats.weightSold.toFixed(2)} <span className="text-[10px]">كغ</span></p>
                </div>
              </div>
            </div>

            <div className="mt-6 p-4 bg-orange-50 rounded-2xl border border-orange-100">
              <p className="text-xs font-bold text-orange-800 mb-1">ملاحظة تقنية</p>
              <p className="text-[10px] text-orange-700 leading-relaxed font-medium">
                هذه التقارير تعتمد على سجل العمليات المؤرشف في ذاكرة المتصفح. لا يتم مسح أي بيانات عند انتهاء اليوم، مما يتيح لك مراجعة أي تاريخ سابق بدقة.
              </p>
            </div>
          </div>
        )}

        {/* Log View */}
        {currentView === 'log' && (
          <div className="p-4 space-y-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
            <h2 className="text-xl font-bold">سجل العمليات الكامل</h2>
            
            <Tabs defaultValue="sales" className="w-full">
              <TabsList className="w-full grid grid-cols-2 mb-4 h-12 p-1 bg-gray-200 rounded-xl">
                <TabsTrigger value="sales" className="rounded-lg font-bold">سجل المبيعات</TabsTrigger>
                <TabsTrigger value="purchases" className="rounded-lg font-bold">سجل المشتريات</TabsTrigger>
              </TabsList>
              
              <TabsContent value="sales" className="space-y-2">
                {sales.length === 0 && <p className="text-center py-10 text-muted-foreground text-sm">لا يوجد سجل مبيعات حتى الآن</p>}
                {sales.map(s => (
                  <div key={s.id} className="bg-white p-3 rounded-xl border shadow-sm space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-sm">{s.productName}</span>
                      <span className="text-[10px] text-muted-foreground">{format(s.timestamp, 'HH:mm - dd/MM')}</span>
                    </div>
                    <div className="flex justify-between items-end">
                      <div className="text-[10px] space-x-2 space-x-reverse">
                        <span>الوزن: {s.weight.toFixed(2)}</span>
                        <span>سعر الكيلو: {s.pricePerKg.toLocaleString()}</span>
                      </div>
                      <span className="text-sm font-black text-green-700">{s.totalPrice.toLocaleString()} ل.س</span>
                    </div>
                  </div>
                ))}
              </TabsContent>

              <TabsContent value="purchases" className="space-y-2">
                {purchases.length === 0 && <p className="text-center py-10 text-muted-foreground text-sm">لا يوجد سجل مشتريات حتى الآن</p>}
                {purchases.map(p => (
                  <div key={p.id} className="bg-white p-3 rounded-xl border shadow-sm space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-sm">{p.productName}</span>
                      <span className="text-[10px] text-muted-foreground">{format(p.timestamp, 'HH:mm - dd/MM')}</span>
                    </div>
                    <div className="flex justify-between items-end">
                      <div className="text-[10px] space-x-2 space-x-reverse">
                        <span>الوزن: {p.weight.toFixed(2)}</span>
                        <span>سعر الشراء: {p.pricePerKg.toLocaleString()}</span>
                      </div>
                      <span className="text-sm font-black text-red-700">{p.totalPrice.toLocaleString()} ل.س</span>
                    </div>
                  </div>
                ))}
              </TabsContent>
            </Tabs>
          </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t px-1 h-20 z-30 flex items-center justify-around max-w-md mx-auto shadow-[0_-4px_10px_rgba(0,0,0,0.05)]">
        <BottomNavItem 
          active={currentView === 'sales'} 
          onClick={() => setCurrentView('sales')} 
          icon={<ShoppingCart size={22} />} 
          label="مبيعات" 
        />
        <BottomNavItem 
          active={currentView === 'purchases'} 
          onClick={() => setCurrentView('purchases')} 
          icon={<Truck size={22} />} 
          label="توريد" 
        />
        <BottomNavItem 
          active={currentView === 'inventory'} 
          onClick={() => setCurrentView('inventory')} 
          icon={<Package size={22} />} 
          label="مخزون" 
        />
        <BottomNavItem 
          active={currentView === 'reports'} 
          onClick={() => setCurrentView('reports')} 
          icon={<BarChart3 size={22} />} 
          label="أرشيف" 
        />
        <BottomNavItem 
          active={currentView === 'log'} 
          onClick={() => setCurrentView('log')} 
          icon={<History size={22} />} 
          label="سجل" 
        />
      </nav>

      <Toaster />
    </div>
  );
}

function BottomNavItem({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex flex-col items-center justify-center gap-1 w-full h-full transition-all duration-200 relative",
        active 
          ? "text-primary scale-110" 
          : "text-muted-foreground opacity-60 hover:opacity-100"
      )}
    >
      <div className={cn(
        "p-1.5 rounded-xl transition-colors",
        active && "bg-primary/10"
      )}>
        {icon}
      </div>
      <span className="text-[10px] font-bold">{label}</span>
      {active && <div className="absolute bottom-1 w-1 h-1 bg-primary rounded-full" />}
    </button>
  );
}

function ReportMobileCard({ title, value, color }: { title: string; value: number; color: string }) {
  return (
    <div className={cn("p-4 rounded-2xl flex justify-between items-center shadow-sm", color)}>
      <h3 className="font-bold text-sm">{title}</h3>
      <p className="text-xl font-black">
        {value.toLocaleString()} <span className="text-[10px] font-normal">ل.س</span>
      </p>
    </div>
  );
}
