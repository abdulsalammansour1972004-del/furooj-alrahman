import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'فروج الرحمن - نظام إدارة',
  description: 'نظام نقاط بيع متكامل لإدارة مبيعات ومشتريات ومخزون الدجاج - فروج الرحمن',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&display=swap" rel="stylesheet" />
      </head>
      <body className="antialiased selection:bg-primary selection:text-white font-['Tajawal',_sans-serif]">
        {children}
      </body>
    </html>
  );
}
