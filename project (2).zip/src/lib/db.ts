
export interface Product {
  id: string;
  name: string;
  currentQty: number; // in kg
  purchasePrice: number; // per kg
  sellingPrice: number; // per kg
}

export interface Sale {
  id: string;
  productId: string;
  productName: string;
  weight: number;
  pricePerKg: number;
  totalPrice: number;
  costPerKg: number;
  profit: number;
  timestamp: number;
}

export interface Purchase {
  id: string;
  productId: string;
  productName: string;
  weight: number;
  pricePerKg: number;
  totalPrice: number;
  timestamp: number;
}

const DB_NAME = 'ChickenPOS_DB_Syria';
const DB_VERSION = 1;

export const initDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);

    request.onupgradeneeded = (event) => {
      const db = request.result;
      if (!db.objectStoreNames.contains('products')) {
        db.createObjectStore('products', { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains('sales')) {
        const salesStore = db.createObjectStore('sales', { keyPath: 'id' });
        salesStore.createIndex('timestamp', 'timestamp', { unique: false });
      }
      if (!db.objectStoreNames.contains('purchases')) {
        const purchasesStore = db.createObjectStore('purchases', { keyPath: 'id' });
        purchasesStore.createIndex('timestamp', 'timestamp', { unique: false });
      }
    };
  });
};

export const getAllFromStore = <T>(storeName: string): Promise<T[]> => {
  return initDB().then(db => {
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(storeName, 'readonly');
      const store = transaction.objectStore(storeName);
      const request = store.getAll();
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  });
};

export const addToStore = <T>(storeName: string, item: T): Promise<void> => {
  return initDB().then(db => {
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(storeName, 'readwrite');
      const store = transaction.objectStore(storeName);
      const request = store.put(item);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  });
};

export const deleteFromStore = (storeName: string, id: string): Promise<void> => {
  return initDB().then(db => {
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(storeName, 'readwrite');
      const store = transaction.objectStore(storeName);
      const request = store.delete(id);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  });
};

export const clearStore = (storeName: string, filter?: (item: any) => boolean): Promise<void> => {
  return initDB().then(db => {
    return new Promise((resolve, reject) => {
      const transaction = db.transaction(storeName, 'readwrite');
      const store = transaction.objectStore(storeName);
      
      if (!filter) {
        const request = store.clear();
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      } else {
        const request = store.openCursor();
        request.onsuccess = (event: any) => {
          const cursor = event.target.result;
          if (cursor) {
            if (filter(cursor.value)) {
              cursor.delete();
            }
            cursor.continue();
          } else {
            resolve();
          }
        };
        request.onerror = () => reject(request.error);
      }
    });
  });
};
