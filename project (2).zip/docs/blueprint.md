# **App Name**: CluckCounter

## Core Features:

- Local Menu Catalog: Maintain a full directory of chicken products, sides, and beverages stored entirely on the device.
- Cart and Checkout System: Real-time order builder allowing users to add items, modify quantities, and calculate subtotals with zero latency.
- IndexedDB Persistence Layer: Automatic local storage of all menu items and transactions using IndexedDB to ensure data persists through reloads.
- Offline Transaction Logging: Every sale is timestamped and stored locally for audit purposes, requiring no server connectivity.
- Sales History Viewer: A dashboard to browse past orders, view specific receipts, and check daily performance summaries.
- Custom Category Manager: Interface for the merchant to create and organize item groups (e.g., 'Buckets', 'Dips') for faster navigation.
- PWA Sync Readiness: A standalone interface that enables the POS to be 'installed' on tablets for a full-screen, app-like experience.

## Style Guidelines:

- Primary color: A warm, savory Amber (#D46312) to evoke a modern, high-quality rotisserie aesthetic.
- Background color: A clean, slightly warm Oyster White (#FAF9F8) that maintains high readability in busy kitchen environments.
- Accent color: A bold Crimson (#EB1422) for high-importance interactions like 'Finalize Order' or 'Void'.
- Using 'Inter' for all UI elements to ensure a machined, objective, and highly legible look across various screen sizes.
- Dual-pane dashboard layout: Navigation and menu categories on the left, an persistent, scrolling active receipt panel on the right.
- Crisp, monochromatic line icons to represent product categories (Poultry, Soda, Fries) for immediate recognition.
- Rapid micro-interactions; when an item is added to the cart, it uses a subtle 150ms slide animation to signify addition without blocking input.